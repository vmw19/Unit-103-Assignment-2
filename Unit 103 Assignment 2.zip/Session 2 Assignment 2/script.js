console.log("Script");
const URL=""

console.log(URL);

client="Healthy Food Potential Shoppers";

let productName=prompt("Enter product name");
let productQuantity=prompt("Enter product quantity");
let productPrice=(2.99);
var stateTaxes=(0.07);


let name=(`Victoria's Health Food Store`);

console.log("client");
document.write(`<h3>Welcome to ${name}. We have a wide variety of organic and vegan based products. Feel free to browse around. This is an amazing health food item: ${productName}, ${productQuantity}$ *${productPrice} and the taxes are ${stateTaxes}.</h3>`);
